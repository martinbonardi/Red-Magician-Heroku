﻿      ___           ___           ___           ___               
     /  /\         /__/\         /  /\         /  /\      ___     
    /  /:/_       |  |::\       /  /::\       /  /::\    /  /\    
   /  /:/ /\      |  |:|:\     /  /:/\:\     /  /:/\:\  /  /:/    
  /  /:/ /::\   __|__|:|\:\   /  /:/~/::\   /  /:/~/:/ /__/::\    
 /__/:/ /:/\:\ /__/::::| \:\ /__/:/ /:/\:\ /__/:/ /:/  \__\/\:\__ 
 \  \:\/:/~/:/ \  \:\~~\__\/ \  \:\/:/__\/ \  \:\/:/      \  \:\/\
  \  \::/ /:/   \  \:\        \  \::/       \  \::/        \__\::/
   \__\/ /:/     \  \:\        \  \:\        \  \:\        /__/:/ 
     /__/:/       \  \:\        \  \:\        \  \:\       \__\/  
     \__\/         \__\/         \__\/         \__\/              


SMAPI lets you run Stardew Valley with mods. Don't forget to download mods separately.

Need help? See:
   - Install guide: http://canimod.com/for-players/install-smapi
   - Troubleshooting: http://canimod.com/for-players/faqs#troubleshooting
   - Ask for help: https://discord.gg/kH55QXP
